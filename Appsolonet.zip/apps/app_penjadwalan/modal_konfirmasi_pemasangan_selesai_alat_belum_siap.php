<div class="modal fade" id="modal_konfirmasi_pemasangan_selesai<?php echo $data['id_register']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<div class="alert alert-success"><strong><center>PERHATIAN</center></strong></div>
			</div>
			<div class="modal-body">
				<h4><center>Alat belum siap kok meh di pasang !!</center></h4>
			</div> 
			<div class = "modal-footer">
				<button type="button" class="btn btn-success" data-dismiss="modal">OK</button>
			</div>
		</div>
	</div>
</div>
                