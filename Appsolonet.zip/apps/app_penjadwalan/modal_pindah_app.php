<div class="modal fade" id="modal_pindah_app" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<div class="alert alert-info"><strong><center>MAU PINDAH DI APLIKASI APA GAN ???	</center></strong></div>
			</div>
			<div class="modal-body">
				<form  method="POST" enctype="multipart/form-data">
				<h4 class="modal-title" id="myModalLabel">
					<center>
						<a href="#" class="btn btn-success">PENJADWALAN</a>
						&nbsp;
						<a href="../app_mon/" target="_blank" class="btn btn-success">MONITORING</a>
					</center>
				</h4>
				<br>
				<div class = "modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
				</div>
				</form> 
			</div>                                
		</div>
	</div>
</div>
                