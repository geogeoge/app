<section class="sidebar">
  <!-- sidebar menu: : style can be found in sidebar.less -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="header" align="center"><font color="white">MENU UTAMA</font></li>
    <li><a href="?page=page_dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
    <li><a href="?page=page_log_transaksi_billing"><i class="fa fa-book"></i> <span>Daily Billing</span></a></li>
<!--     <li><a href="?page=page_data_transaksi_masuk"><i class="fa fa-book"></i> <span>Data Kas Masuk</span></a></li>
 -->    <li><a href="?page=page_access_data_transaksi_tidak_terdeteksi"><i class="fa fa-user-times"></i> <span>Transaksi Tidak Teridentifikasi</span></a></li>
    
    <li class="header" align="center"><font color="white">BILLING ACCESS</font></li>
    <li><a href="?page=page_access_invoice_user_baru"><i class="fa fa-file-o"></i> <span>User Baru</span></a></li>
    <li><a href="?page=page_access_tagihan_bulanan"><i class="fa fa-money"></i> <span>Tagihan Bulanan</span></a></li>
    <li><a href="?page=page_access_data_user_close"><i class="glyphicon glyphicon-ok"></i> <span>User Close</span></a></li>
    <li><a href="?page=page_access_data_user_hold"><i class="glyphicon glyphicon-remove"></i> <span>User Hold</span></a></li>
    <!-- <li><a href="?page=page_validasi_bank"><i class="fa fa-money"></i> <span>Validasi Bank</span></a></li> -->
    <!--<li class="treeview active">
      <a href="#">
        <i class="fa fa-users"></i><span>Kelola User Access</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
      </a>
      <ul class="treeview-menu">
        <li><a href="?page=page_manu_input_user"><i class="fa fa-book"></i> <span>Input User</span></a></li>
        <li><a href="?page=page_access_data_user_close"><i class="fa fa-circle-o"></i> <span>User Close</span></a></li>
        <li><a href="?page=page_access_data_user_hold"><i class="fa fa-circle-o"></i> <span>User Hold</span></a></li>
      </ul> -->
    </li>
    
    <!--<li class="header" align="center"><font color="white">BILLING DIAL UP</font></li>-->
    <!--<li><a href="?page=page_dialup_tagihan_bulanan"><i class="fa fa-money"></i> <span>Tagihan Bulanan</span></a></li>-->
    <!--<li><a href="?page=page_dialup_data_user_close"><i class="glyphicon glyphicon-remove"></i> <span>User Non-Active</span></a></li>-->
    <li class="header" align="center"><font color="white">MENU LAIN - LAIN</font></font></li>
    <li><a href="../../logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
  </ul>
</section>