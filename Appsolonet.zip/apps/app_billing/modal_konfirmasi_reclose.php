<div class="modal fade" id="konfirmasi_reclose" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<div class="alert alert-info"><strong><center>KONFIRMASI RECLOSE</center></strong></div>
			</div>
			<div class="modal-body">

				<h4 class="modal-title" id="myModalLabel"><center>Mau anda kirim kemana data ini ?</h4>
				<br>
				<div class = "modal-footer">
					<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
            		<button name="proses_reclose_teknisi" type="submit" class="btn btn-info">Teknisi</button>
            		<button name="proses_reclose_trial" type="submit" class="btn btn-warning">Trial</button>
            		<button name="proses_reclose_biling" type="submit" class="btn btn-success pull-right">Billing</button>
				</div>
			</div>                                
		</div>
	</div>
</div>
                