<div class="modal fade" id="modal_edit_target_omset" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<div class="alert alert-info"><strong><center>RUBAH TARGET</center></strong></div>
			</div>
			<div class="modal-body">
				<form  method="POST" enctype="multipart/form-data">
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Januari</label>
					<div class="col-sx-10">
						<input type="text" name="januari" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Februari</label>
					<div class="col-sx-10">
						<input type="text" name="februari" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Maret</label>
					<div class="col-sx-10">
						<input type="text" name="maret" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">April</label>
					<div class="col-sx-10">
						<input type="text" name="april" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Mei</label>
					<div class="col-sx-10">
						<input type="text" name="mei" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Juni</label>
					<div class="col-sx-10">
						<input type="text" name="jun" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Juli</label>
					<div class="col-sx-10">
						<input type="text" name="Jul" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Agustus</label>
					<div class="col-sx-10">
						<input type="text" name="agustus" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">September</label>
					<div class="col-sx-10">
						<input type="text" name="september" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Oktober</label>
					<div class="col-sx-10">
						<input type="text" name="oktober" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">November</label>
					<div class="col-sx-10">
						<input type="text" name="november" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sx-2 control-label" for="inputEmail">Desember</label>
					<div class="col-sx-10">
						<input type="text" name="desember" id="inputEmail" class = "form-control" required="required">
					</div>
				</div>
				<div class = "modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
					<button name = "tombol_konfirmasi_pemasangan_selesai" class="btn btn-success">UPDATE</button>
				</div>
				</form> 
			</div>                                
		</div>
	</div>
</div>
                