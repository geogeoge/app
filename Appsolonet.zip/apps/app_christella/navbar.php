<section class="sidebar">
  <!-- sidebar menu: : style can be found in sidebar.less -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="header" align="center"><font color="white">APLIKASI SEMENTARA</font></li>
    <li><a href="?page=page_dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
    <li><a href="../../logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
    <li class="header" align="center"><font color="white">MENU BILLING</font></li>
    <li><a href="?page=page_data_transaksi_masuk"><i class="fa fa-book"></i> <span>Data Pembayaran</span></a></li>
    <li><a href="?page=page_access_invoice_user_baru"><i class="fa fa-user"></i> <span>User Baru</span></a></li>
    <li><a href="?page=page_access_tagihan_bulanan"><i class="fa fa-user"></i> <span>Data Tagihan</span></a></li>
    <li><a href="?page=page_access_data_transaksi_tidak_terdeteksi"><i class="fa fa-user-times"></i> <span>Transaksi Tidak Teridentifikasi</span></a></li>
    <li class="header" align="center"><font color="white">MENU MARKETING</font></li>
    <li><a href="?page=page_data_user_setiap_bulan"><i class="fa fa-book"></i> <span>Data User Setiap Bulan</span></a></li>
    <li><a href="?page=page_pendapatan_marketing"><i class="fa fa-book"></i> <span>Data Pendapatan Marketing</span></a></li>
  </ul>
</section>