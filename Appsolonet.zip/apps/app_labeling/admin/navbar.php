<section class="sidebar">
  <!-- sidebar menu: : style can be found in sidebar.less -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="header" align="center">MENU UTAMA</li>
    <li><a href="?page=page_menu_bts"><i class="fa fa-book"></i> <span>Menu BTS</span></a></li>
    <li><a href="?page=page_menu_room"><i class="fa fa-book"></i> <span>Menu Room</span></a></li>
    <li><a href="?page=page_menu_rak"><i class="fa fa-book"></i> <span>Menu Rak</span></a></li>
    <li><a href="?page=page_menu_device"><i class="fa fa-book"></i> <span>Menu Device</span></a></li>
    <li><a href="?page=page_menu_label"><i class="fa fa-book"></i> <span>Menu Label</span></a></li>
    <li><a href="?page=page_menu_user"><i class="fa fa-book"></i> <span>Menu User</span></a></li>
    <li><a href="../../../logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
  </ul>
</section>