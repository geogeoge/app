
<section class="sidebar">
  <!-- sidebar menu: : style can be found in sidebar.less -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="header" align="center"><font color="white">Menu Marketing</font></li>
    <li><a href="../app_marketing/?page=page_dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
    <li><a href="?page=page_data_persebaran"><i class="fa fa-random"></i> <span>Data Persebaran User</span></a></li>
    <li><a href="../app_marketing/?page=page_data_user_prospek"><i class="fa fa-user"></i> <span>User Prospek</span></a></li>
    <li><a href="../app_marketing/?page=page_data_user_trial"><i class="fa fa-file"></i> <span>Data Sedang Diproses</span></a></li>
    <li class="treeview">
      <a href="#">
        <i class="fa fa-book"></i><span>Data Register</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
      </a>
      <ul class="treeview-menu">
        <li><a href="../app_marketing/?page=page_data_user_close"><i class="fa fa-circle-o"></i> <span>Data User Close</span></a></li>
        <li><a href="../app_marketing/?page=page_data_user_hold"><i class="fa fa-circle-o"></i> <span>Data User Hold</span></a></li>
      </ul>
    </li>
    <li><a href="../app_marketing/?page=page_jadwal_teknisi"><i class="fa fa-calendar"></i> <span>Jadwal Teknisi</span></a></li>
    <li><a href="../../logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
  </ul>
</section>